/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackmanager;

/**
 *
 * @author Estudiantes
 */
public class StackManager {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Stack mipila=new Stack();
        mipila.push(new Person("Karen", 24, "karen24@unicesmag.edu.co", 'F'));
        mipila.push(new Person("Lucia", 24, "lucia123@unicesmag.edu.co", 'F'));
        mipila.push(new Person("Andres", 24, "andres@unicesmag.edu.co", 'M'));
        mipila.push(new Person("Joan", 500, "ayala@unicesmag.edu.co", 'M'));
        mipila.push(new Person("Magda", 42, "Magda@unicesmag.edu.co", 'F'));
        
        Person p1=mipila.peek();
        System.out.println(p1.name);
        
        Person p2=mipila.peek();
        System.out.println(p2.name);
        
        System.out.println("");
        Person p3=mipila.pop();
        System.out.println(p3.name);
        
        Person p4=mipila.pop();
        System.out.println(p4.name);
        
        System.out.println("");
        System.out.println(mipila.peek().name);
        
    }
    
}
