/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackmanager;

/**
 *
 * @author Estudiantes
 */
public class Stack {
    private Node root;
    int size;   
    
    
    void push(Person p){
        if(root==null){
            root=new Node(p, null);
            size=1;
            return;
        }
        Node aux=root;
        for (int i = 0; i < size-1; i++) {
            aux=aux.next;
        }
        aux.next=new Node(p, null);
        size++;
        
    }
    
    Person pop(){
        return delete(size-1);
    }
    
    Person peek(){
        return get(size-1);
    }
    
    private Person get(int index){
        Node aux=root;
        for (int i = 0; i < index; i++) {
            aux=aux.next;
        }
        return aux.data;
    }
    
    private Person delete(int index){
        if(index==0){
            Person p=root.data;
            root=root.next;
            size--;
            return p;
        }
        Node aux=root;
        //Para llegar a la posición anterior index-1
        for (int i = 0; i < index-1; i++) {
            aux=aux.next;
        }
        Person p=aux.next.data;
        aux.next=aux.next.next;
        size--;
        return p;        
    }
    
}
